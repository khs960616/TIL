import { Room } from "../room/utils/room"
import * as uuid from "uuid";

class RoomManager {
  private rooms: Map<string, Room>;

  constructor() {
    this.rooms = new Map<string, Room>();
  }

  createRoom(): Room {
    const roomId = uuid.v4();
    const newRoom = new Room(roomId);
    this.rooms.set(roomId, newRoom);
    return newRoom;
  }

  getRoom(roomId: string): Room|undefined {
    return this.rooms.get(roomId);
  }

  deleteRoom(roomId: string): void {
    this.rooms.delete(roomId);
  }

  exists(id: string): boolean {
    return this.rooms.has(id);
  }
}

export const roomManager = new RoomManager();